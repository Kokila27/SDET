package Question7;
import java.util.ArrayList;
import java.util.Scanner;

public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		ArrayList<Employee> al = new ArrayList<Employee>();
		Employee e;
		int id=0,findid,salary=0,f=0;
		String name,address,findname;
		Character flag='Y';
		System.out.println("Enter the details of employee");
		while(flag=='Y') {
			System.out.println("Employee id: ");
			id = in.nextInt();
			System.out.println("Employee name: ");
			name = in.next();
			System.out.println("Employee address: ");
			address = in.next();
			System.out.println("Employee salary: ");
			salary = in.nextInt();
			al.add(new Employee(id, name, address, salary));
			System.out.println("Do you want add more employee if yes type 'y' or type no 'n'?");
			flag=Character.toUpperCase(in.next().charAt(0));
		}
		flag='Y';
		System.out.println("***********************************"+"\nTotal no.of Employee: "+Employee.empcount);
		while(flag=='Y') {
			System.out.println("Enter the employee id and name which you want to search");
			findid = in.nextInt();
			findname = in.next();
			for(Employee s: al) {
				if(s.getEmpid()==findid && findname.compareTo(s.getEmpname())==0) {
					System.out.println("Employee details"+"ID: "+s.getEmpid()+"Name: "+s.getEmpname()+"Address: "+s.getEmpaddress()+"Salary: "+s.getEmpsalary());
					f=1;
				}

			}
			if(f==0) {
				System.out.println("Invalid Employee ID or Name");
			}
			f=0;
			System.out.println("Do you want add more employee if yes type 'y' or type no 'n'?");
			flag=Character.toUpperCase(in.next().charAt(0));
		}
		
	}

}

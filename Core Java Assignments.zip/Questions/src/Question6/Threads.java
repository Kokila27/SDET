package Question6;
import java.util.Calendar;

public class Threads  extends Thread{
	public void run() {
		System.out.println("Thread is running.....");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threads t1 = new Threads();
		t1.start();
		System.out.println("Thread name: "+t1.getName());
		t1.setName("MyThread");
		System.out.println("Thread name after changing: "+t1.getName());
		System.out.println("Current time: "+Calendar.getInstance().getTime());
		try {
			t1.sleep(10000);
			System.out.println("After Thread sleep for 10 seconds: "+Calendar.getInstance().getTime());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

package music;

public interface Playable {
	Playable veena = null;
	Playable Saxophone = null;
	public void play();
}

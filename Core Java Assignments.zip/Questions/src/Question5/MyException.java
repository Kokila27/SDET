package Question5;

class MyException extends Exception
{
	public MyException(String errormsg) 
	{
		super(errormsg);
	}
}
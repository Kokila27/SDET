package Question5;
import java.util.Scanner;

public class Question5{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the person name: ");
		String name = in.next();
		System.out.println("Enter the age of the person: ");
		int age = in.nextInt();
		try {
			if(age>=18 && age<60) {
				System.out.println("Valid person");
			}else {
				throw new MyException("Invalid age");
			}			
		}
		catch(MyException message) {
			System.out.println("User Defined: "+message);
		}
	}

}

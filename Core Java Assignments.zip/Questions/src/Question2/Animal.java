package Question2;
class Animal{  
void shout()
{
	System.out.println("Animals are having different shouting...");
}  
public static void main(String[] args){  
Animal a= new Animal();
a.shout();
a=new Dog();  
a.shout();  
a=new Cat();  
a.shout();  
a=new Horse();  
a.shout(); 
}  
}
class Dog extends Animal{  
void shout(){System.out.println("Dog is shouting like BOW BOW BOW ");}  
}  
class Cat extends Animal{  
void shout(){System.out.println("Cat is shouting like MEOW MEOW MEOW");}  
}  
class Horse extends Animal
{  
void shout()
{
	System.out.println("Horse is shouting like Neigh Neigh Neigh.");
	}  
}

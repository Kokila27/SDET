package Question3;

public abstract class Instrument 
{
	public abstract void play();
	
	public static void main(String[] args) {
		Instrument p = new Piano();
		Instrument f = new Flute();
		Instrument g = new Guitar();
		String ar[] = {"Piano","Flute","Guitar","Flute","Flute","Guitar","Flute","Piano","Flute","Guitar"};
		for(int i=0;i<ar.length;i++) {
			switch(ar[i]) {
				case "Piano":
					p.play();
					break;
				case "Flute":
					f.play();
					break;
				case "Guitar":
					g.play();
					break;
			}
		}
		
	}
}
